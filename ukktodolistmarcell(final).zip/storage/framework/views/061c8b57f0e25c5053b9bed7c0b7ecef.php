<!DOCTYPE html>
<html>
<head>
    <title>Reminder Tugas</title>
</head>
<body>
    <h2>Halo, ini pengingat tugas Anda!</h2>
    <p>Berikut adalah daftar tugas yang mendekati deadline:</p>
    <ul>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <strong><?php echo e($task->name); ?></strong> - 
                Deadline: <?php echo e(\Carbon\Carbon::parse($task->deadline)->format('d-m-Y')); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>    
    <p>Jangan lupa untuk menyelesaikannya tepat waktu!</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ujikomlah\resources\views/emails/task_reminder.blade.php ENDPATH**/ ?>