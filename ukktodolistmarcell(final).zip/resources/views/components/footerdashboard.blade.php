<footer class="border-t border-gray-300 mx-4 mt-4 sm:mb-0 mb-12 text-gray-600 py-4 text-center">
    &copy;Marcell Fia Dinata - Ujikom 2025 Paket 2
</footer>