<?php $__env->startSection('content'); ?>

    <main id="main-content" class="sm:ml-16 sm:mr-8 mt-24 px-6 transition-all duration-300 ease-in-out">
        <h2 class="text-2xl font-bold mb-4 text-gray-600 dark:text-white">Tasks</h2>
        <div class="mx-auto my-8 bg-white border rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Ubah Tugas</h2>
            <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
        
                <!-- Nama Tugas -->
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Task Name</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?php echo e($task->name); ?>"
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-[#EB5A3C] focus:border-[#EB5A3C]"
                        <?php echo e($task->status ? 'disabled' : ''); ?>

                        required
                    />
                </div>
        
                <!-- Status -->
                <div class="mb-4">
                    <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                    <select
                        id="status"
                        name="status"
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-[#EB5A3C] focus:border-[#EB5A3C]"
                        disabled 
                    >
                        <option value="0" <?php echo e(!$task->status ? 'selected' : ''); ?>>Belum Selesai</option>
                        <option value="1" <?php echo e($task->status ? 'selected' : ''); ?>>Selesai</option>
                    </select>
                </div>
        
                <!-- Prioritas -->
                <div class="mb-4">
                    <label for="priority" class="block text-sm font-medium text-gray-700">Priority</label>
                    <select
                        id="priority"
                        name="priority"
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-[#EB5A3C] focus:border-[#EB5A3C]"
                        <?php echo e($task->status ? 'disabled' : ''); ?>

                    >
                        <option value="normal" <?php echo e($task->priority === 'normal' ? 'selected' : ''); ?>>Normal</option>
                        <option value="medium" <?php echo e($task->priority === 'medium' ? 'selected' : ''); ?>>Medium</option>
                        <option value="high" <?php echo e($task->priority === 'high' ? 'selected' : ''); ?>>High</option>
                    </select>
                </div>
        
                <!-- Deadline -->
                <div class="mb-4">
                    <label for="deadline" class="block text-sm font-medium text-gray-700">Deadline</label>
                    <input
                        type="date"
                        id="deadline"
                        name="deadline"
                        value="<?php echo e($task->deadline); ?>"
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-[#EB5A3C] focus:border-[#EB5A3C]"
                        min="<?php echo e(date('Y-m-d')); ?>"
                        <?php echo e($task->status ? 'disabled' : ''); ?>

                        required
                    />
                </div>
        
                <!-- Tombol Submit -->
                <div class="flex justify-end gap-2">
                    <a href="<?php echo e(route('tasks.index')); ?>" 
    class="border border-gray-500 bg-gray-100 text-gray-500 px-6 py-2 rounded-lg shadow hover:bg-gray-500 hover:text-white">
    Kembali
</a>

<button
    type="submit"
    class="border border-blue-500 bg-blue-100 text-blue-500 px-6 py-2 rounded-lg shadow hover:bg-blue-500 hover:text-white disabled:bg-blue-300 disabled:text-blue-200 disabled:border-blue-300 disabled:cursor-not-allowed"
    <?php if($task->status): echo 'disabled'; endif; ?>
>
    <?php if($task->status): ?>
        Tugas Selesai
    <?php else: ?>
        Perbarui Tugas
    <?php endif; ?>
</button>

                </div>
            </form>
        </div>
        <?php if (isset($component)) { $__componentOriginal26979d60879caf2c0127c5c0946294f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26979d60879caf2c0127c5c0946294f8 = $attributes; } ?>
<?php $component = App\View\Components\Footerdashboard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footerdashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footerdashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26979d60879caf2c0127c5c0946294f8)): ?>
<?php $attributes = $__attributesOriginal26979d60879caf2c0127c5c0946294f8; ?>
<?php unset($__attributesOriginal26979d60879caf2c0127c5c0946294f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26979d60879caf2c0127c5c0946294f8)): ?>
<?php $component = $__componentOriginal26979d60879caf2c0127c5c0946294f8; ?>
<?php unset($__componentOriginal26979d60879caf2c0127c5c0946294f8); ?>
<?php endif; ?>
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ujikomlah\resources\views/home/ubahtugas.blade.php ENDPATH**/ ?>