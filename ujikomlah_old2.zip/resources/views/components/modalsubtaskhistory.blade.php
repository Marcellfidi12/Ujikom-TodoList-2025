<!-- Modal Subtask -->
<div id="subtask-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-4 sm:p-6">
    <div class="bg-white p-6 rounded-lg w-full max-w-lg sm:max-w-md shadow-lg border">
        <h2 class="text-xl font-bold mb-4">Subtasks <span id="subtask-count" class="text-sm text-gray-600"></span></h2>
        <ul id="subtask-list" class="list-none space-y-2 max-h-[200px] overflow-y-auto"></ul>
        <button onclick="closeModal()" class="mt-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-700 w-full">Tutup</button>
    </div>
</div>

<script>
    function openModal(taskId) {
        fetch(`/tasks/${taskId}`)
            .then(response => response.json())
            .then(data => {
                const list = document.getElementById('subtask-list');
                const countDisplay = document.getElementById('subtask-count');
                list.innerHTML = '';
                let completedCount = 0;
                
                if (data.subtasks.length === 0) {
                    list.innerHTML = '<li class="text-gray-500">Subtask kosong</li>';
                    countDisplay.textContent = '';
                } else {
                    data.subtasks.forEach(subtask => {
                        if (subtask.status) completedCount++;
                        list.innerHTML += `
                            <li class="flex items-center border rounded-2xl shadow-md p-4 bg-white">
                                <span class="ml-3 ${subtask.status ? 'text-gray-400 line-through' : 'text-gray-700'}">
                                    ${subtask.name}
                                </span>
                                <span class="ml-auto text-sm font-semibold 
                                    ${subtask.status ? 'text-green-600' : 'text-red-600'}">
                                    ${subtask.status ? 'Selesai' : 'Belum Selesai'}
                                </span>
                            </li>`;
                    });
                    countDisplay.textContent = `(${completedCount}/${data.subtasks.length})`;
                }
                document.getElementById('subtask-modal').classList.remove('hidden');
            });
    }

    function closeModal() {
        document.getElementById('subtask-modal').classList.add('hidden');
    }
</script>