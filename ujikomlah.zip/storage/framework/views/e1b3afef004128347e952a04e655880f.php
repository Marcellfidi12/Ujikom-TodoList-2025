<?php $__env->startSection('content'); ?>
    
    <main id="main-content" class="sm:ml-20 sm:mr-12 mt-24 px-6 transition-all duration-300 ease-in-out">
        <h2 class="text-2xl font-bold mb-4 text-gray-600 dark:text-white">History</h2>
        <div class="mx-auto my-8 bg-white border rounded-lg p-6">
            
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-gray-800 dark:text-gray-200">History</h2>
                <a href="<?php echo e(route('generate.achievement.pdf')); ?>" target="_blank">
                    <button class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Bagikan Pencapaian</button>
                </a>
            </div>
            <!-- Tabel Data -->
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-200">
                    <thead>
                        <tr>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">#</th>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">Task Name</th>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">Subtask</th> 
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">Start At</th>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">Deadline At</th>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">End At</th>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">Status</th>
                            <th class="px-6 py-3 border-b text-left text-sm font-medium text-gray-600">Bukti Selesai</th> <!-- Kolom baru -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-6 py-4 border-b text-sm text-gray-700"><?php echo e($index + 1); ?></td>
                                <td class="px-6 py-4 border-b text-sm text-gray-700"><?php echo e($history->task->name); ?></td>
                                <td class="px-6 py-4 border-b text-xl text-center text-gray-700">
                                    <button onclick="openModal(<?php echo e($history->task->id); ?>)" class="text-gray-500 hover:text-gray-700">
                                        <i class="fa-solid fa-eye"></i>
                                    </button>
                                </td>
                                <td class="px-6 py-4 border-b text-sm text-gray-700"><?php echo e($history->task->created_at->format('Y-m-d')); ?></td>
                                <td class="px-6 py-4 border-b text-sm text-gray-700"><?php echo e($history->task->deadline); ?></td>
                                <td class="px-6 py-4 border-b text-sm text-gray-700"><?php echo e(\Carbon\Carbon::parse($history->end_at)->format('Y-m-d')); ?></td>
                                <td class="px-6 py-4 border-b text-sm font-bold">
                                    <span class="px-2 py-1 rounded text-white 
                                        <?php echo e($history->end_at <= $history->task->deadline ? 'bg-green-600' : 'bg-red-600'); ?>">
                                        <?php echo e($history->end_at <= $history->task->deadline ? 'Selesai Tepat Waktu' : 'Terlambat'); ?>

                                    </span>
                                </td>
            
                                <!-- Kolom Bukti Selesai -->
                                <td class="px-6 py-4 border-b text-sm text-gray-700">
                                    <?php if($history->proof): ?>
                                        <a href="<?php echo e(asset('storage/' . $history->proof)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('storage/' . $history->proof)); ?>" alt="Bukti Selesai" class="w-24 h-24 object-cover rounded">
                                        </a>
                                    <?php else: ?>
                                        <span class="text-gray-500">No Proof</span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="px-6 py-4 text-center text-gray-500">No history available.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>            
        </div>
        <?php if (isset($component)) { $__componentOriginal26979d60879caf2c0127c5c0946294f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26979d60879caf2c0127c5c0946294f8 = $attributes; } ?>
<?php $component = App\View\Components\Footerdashboard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footerdashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footerdashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26979d60879caf2c0127c5c0946294f8)): ?>
<?php $attributes = $__attributesOriginal26979d60879caf2c0127c5c0946294f8; ?>
<?php unset($__attributesOriginal26979d60879caf2c0127c5c0946294f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26979d60879caf2c0127c5c0946294f8)): ?>
<?php $component = $__componentOriginal26979d60879caf2c0127c5c0946294f8; ?>
<?php unset($__componentOriginal26979d60879caf2c0127c5c0946294f8); ?>
<?php endif; ?>
    </main>

    <?php if (isset($component)) { $__componentOriginalbbf7994912b00061d90c2be0dd0e8ca8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbbf7994912b00061d90c2be0dd0e8ca8 = $attributes; } ?>
<?php $component = App\View\Components\Modalsubtaskhistory::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modalsubtaskhistory'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Modalsubtaskhistory::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbbf7994912b00061d90c2be0dd0e8ca8)): ?>
<?php $attributes = $__attributesOriginalbbf7994912b00061d90c2be0dd0e8ca8; ?>
<?php unset($__attributesOriginalbbf7994912b00061d90c2be0dd0e8ca8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbbf7994912b00061d90c2be0dd0e8ca8)): ?>
<?php $component = $__componentOriginalbbf7994912b00061d90c2be0dd0e8ca8; ?>
<?php unset($__componentOriginalbbf7994912b00061d90c2be0dd0e8ca8); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ujikomlah\resources\views/home/history.blade.php ENDPATH**/ ?>