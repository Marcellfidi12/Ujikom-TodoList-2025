<?php $__env->startSection('content'); ?>

  <?php if (isset($component)) { $__componentOriginal78c253ea16bdf83256f4684dea0cc7f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal78c253ea16bdf83256f4684dea0cc7f8 = $attributes; } ?>
<?php $component = App\View\Components\Popup::resolve(['reminders' => $reminders] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('popup'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Popup::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal78c253ea16bdf83256f4684dea0cc7f8)): ?>
<?php $attributes = $__attributesOriginal78c253ea16bdf83256f4684dea0cc7f8; ?>
<?php unset($__attributesOriginal78c253ea16bdf83256f4684dea0cc7f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal78c253ea16bdf83256f4684dea0cc7f8)): ?>
<?php $component = $__componentOriginal78c253ea16bdf83256f4684dea0cc7f8; ?>
<?php unset($__componentOriginal78c253ea16bdf83256f4684dea0cc7f8); ?>
<?php endif; ?>

  <main id="main-content" class="sm:ml-20 sm:mr-12 mt-24 px-6 transition-all duration-300 ease-in-out">
    <h2 class="text-2xl font-bold mb-4 text-gray-600 dark:text-white">Dashboard</h2>
    <div class="flex flex-col sm:flex-row gap-6">
      <!-- Card Kiri -->
      <div class="flex-1 flex flex-col gap-6">
        <!-- Card Atas -->
        <div class="bg-white dark:bg-gray-800 border rounded-lg p-6 h-auto">
          <!-- Content Navigation -->
          <div class="flex justify-between items-center mb-4">
            <button id="prev-content" class="text-gray-600 hover:text-gray-900">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-6 h-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <h4 id="content-title" class="text-md font-semibold dark:text-white">Summary</h4>
            <button id="next-content" class="text-gray-600 hover:text-gray-900">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-6 h-6">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        
          <!-- Content Sections -->
          <div id="content-sections">
            <!-- Summary Section -->
            <div id="summary-section" class="content-section">
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                <div class="bg-gray-100 rounded-lg p-4 shadow-md flex flex-col items-center sm:items-start dark:bg-gray-600 dark:text-white">
                  <h4 class="text-md font-semibold mb-2 text-center sm:text-left">Tasks Completed</h4>
                  <p class="text-lg font-bold text-green-600"><?php echo e($completedTasks); ?></p>
                </div>
        
                <div class="bg-gray-100 rounded-lg p-4 shadow-md flex flex-col items-center sm:items-start dark:bg-gray-600 dark:text-white">
                  <h4 class="text-md font-semibold mb-2 text-center sm:text-left">Tasks Pending</h4>
                  <p class="text-lg font-bold text-yellow-600"><?php echo e($pendingTasks); ?></p>
                </div>
        
                <div class="bg-gray-100 rounded-lg p-4 shadow-md flex flex-col items-center sm:items-start dark:bg-gray-600 dark:text-white">
                  <h4 class="text-md font-semibold mb-2 text-center sm:text-left">Overdue Tasks</h4>
                  <p class="text-lg font-bold text-red-600"><?php echo e($overdueTasks); ?></p>
                </div>
              </div>
            </div>
        
            <!-- Time and Date Section -->
            <div id="date-time-section" class="content-section hidden">
              <div class="pt-4 mt-4">
                <div class="text-center">
                  <p id="current-time" class="text-4xl font-bold text-gray-800 dark:text-white"></p>
                  <p id="current-date" class="text-lg font-bold text-gray-800 dark:text-white"></p>
                </div>
              </div>
            </div>
          </div>
        
          <!-- Motivational Quote Section -->
          <div class="border-t pt-4 mt-4">
            <div class="overflow-hidden">
              <marquee id="motivational-quote" behavior="scroll" direction="left" class="italic text-gray-600 dark:text-gray-300">
                <!-- Kutipan akan diisi secara dinamis dengan JavaScript -->
              </marquee>
            </div>
          </div>
        </div>
  
        <div class="bg-white dark:bg-gray-800 border rounded-lg p-6 h-auto">
          <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-bold text-gray-800 dark:text-gray-200">Reminder<span class="ml-2 text-sm text-gray-500">(<?php echo e($tasks->whereBetween('deadline', [now(), now()->addDays(7)])->where('status', false)->count()); ?>)</span></h2>
            <a href="<?php echo e(route('reminder')); ?>"><button class="text-gray-500 hover:text-blue-600">Lainnya...</button></a>
          </div>
          <ul class="space-y-4 mt-2">
              <?php $__empty_1 = true; $__currentLoopData = $reminders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reminder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li class="flex justify-between items-center border rounded-2xl p-4 bg-white dark:bg-gray-800 shadow-md hover:shadow-lg transition duration-300">
                  <div class="flex items-center">
                      <i class="fa-solid fa-circle-exclamation text-blue-600"></i>
                      <span class="ml-3 text-gray-700 dark:text-gray-300"><?php echo e($reminder->name); ?></span>
                  </div>
                  <span class="text-sm text-gray-500">
                    <?php echo e(abs(floor(\Carbon\Carbon::parse($reminder->deadline)->diffInDays(\Carbon\Carbon::now())))); ?> days left
                  </span>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <p class="text-gray-500 dark:text-gray-300">No reminders for the next 7 days!</p>
              <?php endif; ?>
          </ul>
        </div>      
      </div>

      <!-- Card Kanan -->
      <div class="flex-1 bg-white dark:bg-gray-800 border rounded-lg p-6 overflow-hidden">
        <h2 class="text-2xl font-bold text-center underline text-gray-600 dark:text-gray-200">Tasks <span class="text-sm text-gray-500"></span></h2>
        <!-- Task Filter -->
        <div class="w-full overflow-x-auto whitespace-nowrap">
          <div class="flex space-x-4 mb-4 border-b pb-2 flex-nowrap">
              <button id="btn-all" class="px-4 py-2 border-b-2 border-transparent hover:border-blue-600 dark:text-white" onclick="filterTasks('all', this)">All</button>
              <button id="btn-high" class="px-4 py-2 border-b-2 border-transparent hover:border-blue-600 dark:text-white" onclick="filterTasks('high', this)">High</button>
              <button id="btn-medium" class="px-4 py-2 border-b-2 border-transparent hover:border-blue-600 dark:text-white" onclick="filterTasks('medium', this)">Medium</button>
              <button id="btn-normal" class="px-4 py-2 border-b-2 border-transparent hover:border-blue-600 dark:text-white" onclick="filterTasks('normal', this)">Normal</button>
              <button id="btn-completed" class="px-4 py-2 border-b-2 border-transparent hover:border-green-600 dark:text-white" onclick="filterTasks('completed', this)">Completed</button>
          </div>
        </div>
        
        <!-- Task List -->
        <div class="h-[50vh] pb-4 overflow-y-auto">
            <div id="empty-message" class="hidden h-full flex flex-col items-center justify-center italic text-gray-500">
              <i class="fa-solid fa-inbox text-6xl text-gray-300 mb-4"></i>
              <span class="text-lg font-semibold">Tidak ada tugas terbaru disini</span>
            </div>
            <ul id="task-list" class="space-y-4">
              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="flex items-center border rounded-2xl p-4 bg-white dark:bg-gray-800 shadow-md hover:shadow-lg transition duration-300 task-item <?php echo e($task->status ? 'hidden' : ''); ?>"
                  data-priority="<?php echo e($task->priority); ?>" data-status="<?php echo e($task->status ? 'completed' : 'pending'); ?>">
                  
                  <span class="ml-3 text-lg font-medium 
                      <?php echo e($task->status ? 'text-gray-400 line-through' : 'text-gray-700 dark:text-gray-200'); ?>">
                      <?php echo e($task->name); ?>

                  </span>

                  <span class="ml-auto px-3 py-1 border rounded-full text-xs font-semibold uppercase
                      <?php echo e($task->priority === 'high' ? 'border-red-500 text-red-500 bg-red-100 dark:bg-red-900' : ''); ?>

                      <?php echo e($task->priority === 'medium' ? 'border-yellow-500 text-yellow-500 bg-yellow-100 dark:bg-yellow-900' : ''); ?>

                      <?php echo e($task->priority === 'normal' ? 'border-gray-500 text-gray-500 bg-gray-100 dark:bg-gray-900' : ''); ?>">
                      <?php echo e(ucfirst($task->priority)); ?>

                  </span>
              </li>                    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      </div>

    </div>
    <?php if (isset($component)) { $__componentOriginal26979d60879caf2c0127c5c0946294f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal26979d60879caf2c0127c5c0946294f8 = $attributes; } ?>
<?php $component = App\View\Components\Footerdashboard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footerdashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Footerdashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal26979d60879caf2c0127c5c0946294f8)): ?>
<?php $attributes = $__attributesOriginal26979d60879caf2c0127c5c0946294f8; ?>
<?php unset($__attributesOriginal26979d60879caf2c0127c5c0946294f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26979d60879caf2c0127c5c0946294f8)): ?>
<?php $component = $__componentOriginal26979d60879caf2c0127c5c0946294f8; ?>
<?php unset($__componentOriginal26979d60879caf2c0127c5c0946294f8); ?>
<?php endif; ?>
  </main>

  <script>
    //mengecek tugas saat pertama kali memuat halaman
    window.addEventListener("load", () => {
        checkEmptyTaskList();
    });
    
    const quotes = [
      "Rahasia untuk maju adalah dengan memulainya. – Mark Twain",
      "Jangan memperhatikan jam; melakukan apa yang dilakukannya. Terus berlanjut. – Sam Levenson",
      "Kesuksesan bukanlah sesuatu yang final, kegagalan bukanlah hal yang fatal: Yang terpenting adalah keberanian untuk melanjutkan. – Winston Churchill",
      "Percayalah Anda bisa dan Anda sudah setengah jalan menuju kesuksesan. – Theodore Roosevelt",
      "Cara memulainya adalah dengan berhenti berbicara dan mulai melakukan. – Walt Disney"
    ];

    // Pilih kutipan secara acak
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

    // Tampilkan kutipan ke elemen marquee
    document.getElementById("motivational-quote").textContent = randomQuote;

    // Javascript Waktu & Tanggal 
    function updateDateTime() {
      const optionsDate = { timeZone: 'Asia/Jakarta', year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' };
      const optionsTime = { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' };
        
      const currentDate = new Date().toLocaleDateString('id-ID', optionsDate);
      const currentTime = new Date().toLocaleTimeString('id-ID', optionsTime);
        
      document.getElementById('current-date').textContent = currentDate;
      document.getElementById('current-time').textContent = currentTime;
    }
        
    setInterval(updateDateTime, 1000);
        
    const sections = document.querySelectorAll('.content-section');
    const titles = ["Task Summary", "Time & Date Realtime"];
    let currentSectionIndex = 0;
        
    function updateTitle() {
      document.getElementById('content-title').textContent = titles[currentSectionIndex];
    }
        
    document.getElementById('prev-content').addEventListener('click', () => {
      sections[currentSectionIndex].classList.add('hidden');
      currentSectionIndex = (currentSectionIndex - 1 + sections.length) % sections.length;
      sections[currentSectionIndex].classList.remove('hidden');
      updateTitle();
    });
        
    document.getElementById('next-content').addEventListener('click', () => {
      sections[currentSectionIndex].classList.add('hidden');
      currentSectionIndex = (currentSectionIndex + 1) % sections.length;
      sections[currentSectionIndex].classList.remove('hidden');
      updateTitle();
    });
    
    updateDateTime();
    updateTitle();
  </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ujikomlah\resources\views/home/dashboard.blade.php ENDPATH**/ ?>