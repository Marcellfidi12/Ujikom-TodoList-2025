<footer class="w-full py-4 flex justify-center">
    <div class="w-4/5 border-t border-blue-600 text-center text-gray-500 pt-4">
        <p>&copy;Marcell Fia Dinata - Ujikom 2025 Paket 2</p>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\ujikomlah\resources\views/components/footer.blade.php ENDPATH**/ ?>